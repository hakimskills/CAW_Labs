const mean = require('./notation');
const scores = [2,2, 2, 2, 2];
const average = mean(scores);

console.log(`The average score is: ${average}`);