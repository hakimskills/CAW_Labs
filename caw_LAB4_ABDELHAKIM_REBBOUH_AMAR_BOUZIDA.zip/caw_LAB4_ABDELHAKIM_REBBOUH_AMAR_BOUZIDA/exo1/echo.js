
function echo(a, s) {
    for (let i = 0; i < s; i++) {
        console.log(a);
    }
}

module.exports = { echo };
