
import React, { useState } from 'react';
import Card from './Card';
import Button from './Button';
import './NewTaskForm.css'
import ErrorModal from './ErrorModal';

function NewTaskForm({ addTask }) {
  const [taskText, setTaskText] = useState('');
  const [error ,setError]=useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if(taskText.trim().length===0){
        setError({
            title:'empty',
            message:'please enter valid task (non-empty tasks)'
        })
    }
    if (taskText.trim() !== '') {
      addTask({ text: taskText, subtasks: [] });
      setTaskText('');
    }
  };
  const errorHandler =()=>{
    setError(null);
   
   }

  return (<div>
     { error && <ErrorModal title={error.title} message={error.message} onConfirm={errorHandler}></ErrorModal>}
    <Card className='input' >
    <form onSubmit={handleSubmit}>
        <label id='task'>task</label>
      <input
        type="text"
        placeholder="Enter task description"
        value={taskText}
        onChange={(e) => setTaskText(e.target.value)}
      />
      <Button type='submit' >add Task</Button>
    </form>
    </Card>
    </div>
  );
}

export default NewTaskForm;
