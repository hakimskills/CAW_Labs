
import React, { useState } from 'react';
import './TaskList.css'; 
import Card from './Card';
import Button from './Button';
import ErrorModal from './ErrorModal';

function Task({ index, task, deleteTask }) {
  const [subtaskText, setSubtaskText] = useState('');
  const [subtasks, setSubtasks] = useState([]);
  const [showSubtasks, setShowSubtasks] = useState(false);
  const [error, setError] = useState('');

  const addSubtask = () => {
    if (subtaskText.trim() !== '') {
      setSubtasks([...subtasks, { text: subtaskText, done: false }]);
      setSubtaskText('');
    } else {
      setError({
        title: 'Empty',
        message: 'Please enter a valid subtask (non-empty subtasks)',
      });
    }
  };

  const deleteSubtask = (subtaskIndex) => {
    const updatedSubtasks = subtasks.filter((_, index) => index !== subtaskIndex);
    setSubtasks(updatedSubtasks);
  };

  const toggleSubtask = (subtaskIndex) => {
    const updatedSubtasks = [...subtasks];
    updatedSubtasks[subtaskIndex].done = !updatedSubtasks[subtaskIndex].done;
    setSubtasks(updatedSubtasks);
  };

  const modifySubtask = (subtaskIndex, newText) => {
    const updatedSubtasks = [...subtasks];
    updatedSubtasks[subtaskIndex].text = newText;
    setSubtasks(updatedSubtasks);
  };

  const errorHandler = () => {
    setError(null);
  };

  return (
    <div>
      {error && <ErrorModal title={error.title} message={error.message} onConfirm={errorHandler}></ErrorModal>}
      <Card className='users input'>
        <div>
          <div>
            <strong>Task {index + 1}:</strong> {task.text}{' '}
            <Button onClick={() => setShowSubtasks(!showSubtasks)}>
              {showSubtasks ? 'Hide Sub-Tasks' : 'Show Sub-Tasks'}
            </Button>
            <Button
              style={{ position: 'absolute', right: 0, marginRight: '10px', backgroundColor: 'red' }}
              onClick={() => deleteTask(index)}
            >
              X
            </Button>
          </div>
          {showSubtasks && (
            <div>
              <input
                type='text'
                placeholder='Enter subtask description'
                value={subtaskText}
                onChange={(e) => setSubtaskText(e.target.value)}
              />
              <Button style={{ marginLeft: '20px' }} onClick={addSubtask}>
                Add Sub-Task
              </Button>
              <ul>
                {subtasks.map((subtask, subtaskIndex) => (
                  <li key={subtaskIndex}>
                    {subtask.done ? (
                      <>
                        <span style={{ textDecoration: 'line-through' }}>{subtask.text}</span>{' '}
                        <Button onClick={() => toggleSubtask(subtaskIndex)}>Undo</Button>
                        <Button
                          style={{ position: 'absolute', right: 0, marginRight: '10px', backgroundColor: 'red' }}
                          onClick={() => deleteSubtask(subtaskIndex)}
                        >
                          X
                        </Button>
                      </>
                    ) : (
                      <>
                        <span>{subtask.text}</span>{' '}
                        <Button onClick={() => toggleSubtask(subtaskIndex)}>Done</Button>
                        <Button
                          onClick={() => modifySubtask(subtaskIndex, prompt('Enter new text'))}
                          style={{ position: 'absolute', right: 0, marginRight: '10px', backgroundColor: 'red' }}
                        >
                          Modify
                        </Button>
                        <Button
                          style={{ position: 'absolute', right: 0, marginRight: '10px', backgroundColor: 'red' }}
                          onClick={() => deleteSubtask(subtaskIndex)}
                        >
                          X
                        </Button>
                      </>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}

export default Task;
