import Button from "./Button";
import Card from "./Card";
import ErrorModal from "./ErrorModal";
import './NewTaskForm.css'
import { useState } from "react";
const NewSubTaskList =props=>{

const [enteredSubTask,setEnteredSubTask]=useState([]);
const [error ,setError]=useState('');

const addTask =(event)=>{

event.preventDefault();
if(enteredSubTask.trim().length=== 0){
    setError({
        title:'emty Subtask',
        message:'please enter valid task (non-empty tasks)'

    })
    return;
}
props.onAddTask(enteredSubTask);
setEnteredSubTask('');

}

const subTaskChange=(event)=>{
    setEnteredSubTask(event.target.value)
}
const errorHandler =()=>{
 setError(null);

}
    return( <div>
      { error && <ErrorModal title={error.title} message={error.message} onConfirm={errorHandler}></ErrorModal>}
        <Card className="input">
            
        <form onSubmit={addTask}>
           
           <label htmlFor="sub-task">sub-task</label>
          
          <input value={enteredSubTask} id='sub-task' type="txt" onChange={subTaskChange}></input>
          <Button type='submit' >add task</Button>
           
           
        </form>
      
        </Card>
        </div>
       
    )
}
export default NewSubTaskList;