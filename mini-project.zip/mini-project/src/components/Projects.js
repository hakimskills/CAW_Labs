import './Projects.css'
import riotWeb from '../images/riot.jpeg'
const Projects=()=>{
    return(
        <div className='project'>
         
        </div>
    )
}
export default Projects;