import React from 'react';
import './Skill.css';
import reactLogo from '../images/react.png';
import vueLogo from '../images/vue.png';
import flutterLogo from '../images/flutter.png';
import firebaseLogo from '../images/firebase.png';
import laravelLogo from '../images/laravel.png';

const Skill = () => {
  return (
    <div className='skill'>
      <h1>Skills and Experience</h1>
      <div className="container">
        <div className="left-panel">
          <h2>Experience:</h2>
          As a passionate League of Legends player, I embarked on a project to create a React-based website dedicated to Riot Games. This journey not only aimed to showcase my love for the game but also provide a dynamic platform for the League community.
        </div>
        <div className="bar"></div>
        <div className="right-panel">
          <h2>Skills:</h2>
          <div className="frontend">
            <div className="skill-list">
              <div className="skill-logo">React <img src={reactLogo} alt="React Logo" /></div>
              <div className="skill-logo">Vue.js <img src={vueLogo} alt="Vue.js Logo" /></div>
              <div className="skill-logo">Flutter(Mobile) <img src={flutterLogo} alt="Flutter Logo" /></div>
            </div>
          </div>
          <div className="backend">
            <div className="skill-list">
              <div className="skill-logo">Firebase <img src={firebaseLogo} alt="Firebase Logo" /></div>
              <div className="skill-logo">Laravel <img src={laravelLogo} alt="Laravel Logo" /></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Skill;
