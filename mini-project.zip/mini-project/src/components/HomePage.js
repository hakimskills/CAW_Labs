import AboutMe from "./AboutMe";
import NavBar from "./NavBar";

const HomePage=()=>{
return (    
    <div>


<AboutMe></AboutMe>
    </div>
)
}
export default HomePage ;
