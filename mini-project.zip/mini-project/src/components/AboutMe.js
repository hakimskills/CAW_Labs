    import './AboutMe.css'
    const AboutMe=()=>{
        return(
            <div className="about">
                <h1> i'm hakim rebbouh, wlecome to my portfolio</h1>
                <p>
                "I am a passionate web developer with a strong background 
                in Information Technology. I pursued my studies at the University
                Constantine 2, where I obtained a license in IT .</p>
                <p> My skills encompass
                a variety of technologies, including React, Vue, and Flutter
                . Additionally, I have experience in backend development
                using Laravel. I am dedicated to creating innovative and
                    efficient solutions that meet the needs of modern web development."  
                </p>

            </div>
        ) 

    }
    export default AboutMe;