window.onload = function () {
    var maze = document.getElementById("maze");
    var start = document.getElementById("start");
    var end = document.getElementById("end");
    var boundaries = document.querySelectorAll(".boundary");

    var gameStarted = false;
    var gameWon = false;

    function startOrResetGame() {
        if (gameWon || !gameStarted) {
            gameStarted = true;
            gameWon = false;
            document.getElementById("status").textContent = "Move your mouse to the end without touching the walls.";
            resetMaze();
        }
    }

    start.addEventListener("click", startOrResetGame);

    end.addEventListener("mouseover", function () {
        if (gameStarted && !gameWon) {
            document.getElementById("status").textContent = "You win!";
            gameWon = true;
        }
    });

    for (var i = 0; i < boundaries.length; i++) {
        boundaries[i].addEventListener("mouseover", function () {
            if (gameStarted && !gameWon) {
                turnWallsRed();
            }
        });
    }

    maze.addEventListener("mouseleave", function () {
        if (gameStarted && !gameWon) {
            turnWallsRed();
        }
    });

    maze.addEventListener("contextmenu", function (e) {
        e.preventDefault();
    });

    maze.addEventListener("mousemove", function (e) {
        if (!gameStarted) return;

        var mouseX = e.clientX;
        var mouseY = e.clientY;
        var mazeRect = maze.getBoundingClientRect();

        if (
            mouseX < mazeRect.left ||
            mouseX > mazeRect.right ||
            mouseY < mazeRect.top ||
            mouseY > mazeRect.bottom
        ) {
            turnWallsRed();
        }
    });

    function resetMaze() {
        document.getElementById("status").textContent = "Move your mouse to the end without touching the walls.";
        for (var i = 0; i < boundaries.length; i++) {
            boundaries[i].style.backgroundColor = "#eeeeee";
        }
    }

    function turnWallsRed() {
        document.getElementById("status").textContent = "You lose!";
        for (var i = 0; i < boundaries.length; i++) {
            boundaries[i].style.backgroundColor = "#ff8888";
        }
        gameStarted = false; 
    }
};
